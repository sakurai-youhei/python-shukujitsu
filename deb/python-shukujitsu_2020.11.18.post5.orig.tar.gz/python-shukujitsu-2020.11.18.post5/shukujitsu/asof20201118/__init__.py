from pkgutil import get_data

# https://www8.cao.go.jp/chosei/shukujitsu/syukujitsu.csv
RAW_DATA = get_data("shukujitsu.asof20201118", "syukujitsu.csv")
