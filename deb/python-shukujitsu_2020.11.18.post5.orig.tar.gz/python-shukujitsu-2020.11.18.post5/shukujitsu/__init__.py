from shukujitsu.exports import CountryHoliday
from shukujitsu.exports import Japan
from shukujitsu.exports import JP
from shukujitsu.exports import JPN


__version__ = "2020.11.18.post5"
assert __version__ and CountryHoliday and Japan and JP and JPN
