from shukujitsu.exports import CountryHoliday
from shukujitsu.exports import Japan


__version__ = "2020.11.27"
# aliases
JP = JPN = Japan
assert __version__ and CountryHoliday and Japan and JP and JPN
